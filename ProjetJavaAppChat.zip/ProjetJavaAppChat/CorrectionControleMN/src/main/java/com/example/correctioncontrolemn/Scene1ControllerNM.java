package com.example.correctioncontrolemn;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class Scene1ControllerNM {
    @FXML
    private TextField usernameIdNM;
    @FXML
    private PasswordField passwordIdNM;
    @FXML
    private Button cancelButton;
    @FXML
    protected void onLogin () throws IOException {
        if(usernameIdNM.getText().equals("admin") && passwordIdNM.getText().equals("admin")){
            //je dois savoir le stage ou on existe
            Stage sNM = (Stage) usernameIdNM.getScene().getWindow();
            //Recuperer le fichier fxml de la 2eme scene
            FXMLLoader fxNM = new FXMLLoader(MainApp.class.getResource("Scene2NM.fxml"));
            Scene sc2NM=new Scene(fxNM.load());
            //attacher la scene au stage
            sNM.setScene(sc2NM);
        }
        else{
            //creer une alerte
            Alert alertNM = new Alert(Alert.AlertType.ERROR);
            alertNM.setTitle("Authentication Error");
            alertNM.setHeaderText("Username or password are note validated ");
            alertNM.setContentText("You can retry by changing the authentication information");
            alertNM.show();
        }
    }
    @FXML
    protected void onCancelButtonClick() {
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }
}
