package com.example.correctioncontrolemn;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.*;
import java.net.Socket;
import java.util.*;

public class Scene2ControllerNM {
    @FXML
    private TextField HostID;
    @FXML
    private TextField PortID;
    @FXML
    private TextField MyMsgID;
    @FXML
    private ListView testView;
    @FXML
    private ImageView emojiIcon;
    Optional<String> selectedEmoji;

    @FXML
    private ComboBox<String> emojiSelector;
    private List<String> messageHistory = new ArrayList<>();

    @FXML
    public void initialize() {
        emojiSelector.getItems().addAll("😃", "😊", "👍", "❤", "🎉");
    }

    /*
    @FXML
    public void initialize() {
        emojiIcon.setOnMouseClicked(event -> {
            List<String> emojis = Arrays.asList("😃", "😊", "👍", "❤️", "🎉");
            ChoiceDialog<String> dialog = new ChoiceDialog<>(emojis.get(0), emojis);
            dialog.setTitle("Choisir un emoji");
            dialog.setHeaderText(null);
            dialog.setContentText("Sélectionnez un emoji :");
            selectedEmoji = dialog.showAndWait();

    });}*/
    PrintWriter pw;
    @FXML
    protected void onConnect() throws IOException {
        //interface graphique client
        String host=HostID.getText();
        int port=Integer.parseInt(PortID.getText());
        //Socket
        Socket s = new Socket(host,port);
        InputStream is = s.getInputStream();//octet
        InputStreamReader isr = new InputStreamReader(is);//caractere
        BufferedReader br = new BufferedReader(isr);//lire une chaine de caracteres
        OutputStream os = s.getOutputStream();
        String Ip = s.getRemoteSocketAddress().toString();
        pw = new PrintWriter(os,true);
        //lancer un thread pour afficher les msg des utilisateurs
        new Thread(()->{
            while (true){
                try {
                    //on va stocker chaque reponse dans la chaine de cara reponse
                    String reponse = br.readLine();
                    //on peut pas acceder a un elmnt de javaFx dans un thread
                    Platform.runLater(()->{
                        testView.getItems().add(reponse);
                    });
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
    @FXML
    public void onSubmit(){
        String selectedEmoji = emojiSelector.getValue();
        String msg=MyMsgID.getText();
        if(selectedEmoji==null){
            pw.println(msg);
            messageHistory.add(msg);
        }else {
        String updatedMessage = msg + " " + selectedEmoji;
        pw.println(updatedMessage);
            // Ajouter le message à l'historique
            messageHistory.add(updatedMessage);
        }

        /*
        selectedEmoji.ifPresent(emoji -> {
            String msg=MyMsgID.getText();
            //String selectedEmoji = emojiSelector.getValue();
            String updatedMessage = msg + " " + emoji;
            pw.println(updatedMessage);
        });*/
    }

}


