package com.example.correctioncontrolemn;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.IllegalFormatException;
import java.util.List;
import java.util.Random;

//soit l'heritage ou bien l'implementation de l'interface Runnable
public class ChatWithServer extends Thread{
    private int ClientNbr;
    private List<Communication> clientConnecte =new ArrayList<Communication>();
    public static void main(String[] args) {
        //instancier un nouveau objet de la classe
        new ChatWithServer().start();
    }
    //la redefinition de la classe run
    @Override
    public void run(){
        try {
            //lancer le serveur socket
            ServerSocket ss=new ServerSocket(1234);
            System.out.println("Le serveur essaie de demarrer");
            while (true){
                //accptation de n'importe client
                Socket s = ss.accept();
                //a chaque fois un utilisateur est connecte
                ++ClientNbr;
                //faut l'ajouter a la liste ddes clients
                Communication NewCommunication = new Communication(s,ClientNbr);
                clientConnecte.add(NewCommunication);
                //creer un thread pour communiquer seulement avec ce client(une tache)
                //prends en parametre le socket du client
                NewCommunication.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //creation d'une classe interne:pour encapsuler les donnees de la classe externe
    public class Communication extends Thread{
        //socket du client
        private Socket s;
        private int ClientNbr;
        Communication(Socket s,int ClientNbr){
            this.s=s;
            this.ClientNbr=ClientNbr;
        }
        @Override
        public void run() {
            //echanger de caracteres
            try {
                InputStream is = s.getInputStream();//octet
                InputStreamReader isr = new InputStreamReader(is);//caractere
                BufferedReader br = new BufferedReader(isr);//lire une chaine de caracteres
                OutputStream os = s.getOutputStream();
                String Ip = s.getRemoteSocketAddress().toString();
                System.out.println("le client numero" + ClientNbr + "zt son IP" + Ip);
                PrintWriter pw = new PrintWriter(os, true);//println pour ecrire
                //pour le clients puisse voir son nombre
                pw.println("Vous êtes le client " + ClientNbr);
                pw.println("Envoyer le message que vous voulez!!!");
                while (true) {
                    String userRequest = br.readLine();
                    //methode pour l'envoie une methode que envoie le msg a tout le monde
                    if(userRequest.contains("=>")){
                        String[] usermsg = userRequest.split("=>");
                        //verification de tableau s'il contient 2 ellmts
                        if(usermsg.length==2){
                            String msg = usermsg[1];
                            int numClient= Integer.parseInt(usermsg[0]);
                            Send(msg,s,numClient);
                        }
                    }
                    else {
                        Send(userRequest,s,-1);
                    }

                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        //faut comparer entre les clients et filtrer les utilisateurs
        //le msg va transferer a tout le monde sauf moi =>Socket s
        void Send(String UserRequest,Socket socket,int nbr) throws IOException {
            for(Communication client : clientConnecte){
                if(client.s != socket){
                    if(client.ClientNbr==nbr || nbr==-1){
                        PrintWriter pw = new PrintWriter(client.s.getOutputStream(),true);
                        pw.println(UserRequest);
                    }
                }

            }
        }
    }
}



